export class SalesOrder {
  public No: number;
  public Plant: string;
  public Material: string;
  public RequestedDeliveryDate: Date;
  public SalesDoc: string;
  public SalesToName: string;
  public ShipToName: string;
  public index: number;
}
