import { DragdropDirective } from './dragdrop.directive';

describe('DragdropDirective', () => {
  it('should create an instance', () => {
    const directive = new DragdropDirective();
    expect(directive).toBeTruthy();
  });
});
